if __name__ == '__main__':
    n = int(input())
    for n in range (0,n):
        print(n+1,end="")
